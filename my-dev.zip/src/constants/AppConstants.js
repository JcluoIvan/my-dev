import keymirror from 'keymirror';


export default {
    ActionType: keymirror({
        DEMO: null,
    }),
    StoreEvent: keymirror({
        ON_DEMO: null,
    })
}