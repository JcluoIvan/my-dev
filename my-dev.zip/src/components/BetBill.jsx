
import React from 'react';


class BetBill extends React.Component {
    render () {
        return (<div />);
    }
}


export default BetBill;