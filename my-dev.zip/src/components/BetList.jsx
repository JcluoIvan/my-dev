
import React from 'react';


class BetList extends React.Component {
    render () {
        return (<div />);
    }
}


export default BetList;