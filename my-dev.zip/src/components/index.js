module.exports = {
    SignIn: require('./SignIn'),  
    Main: require('./Main'),  
    BetList: require('./BetList'),  
    BetBill: require('./BetBill'),  
    Navbar: require('./Navbar'),  
    SignIn: require('./SignIn'),  
};